# Screenshots

Add screenshots of the main investigation results here.

Recommended filenames:

- `01-crime-scene-report.png`
- `02-morty-schapiro.png`
- `03-annabel-miller.png`
- `04-gym-membership-candidates.png`
- `05-jeremy-bowers.png`
- `06-concert-attendance.png`
- `07-miranda-priestly-validation.png`

Keep screenshots focused on the query and result so recruiters can quickly understand the evidence.
